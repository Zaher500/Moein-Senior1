# Init core module
